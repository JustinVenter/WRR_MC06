/**
 * Created by Michael on 09/08/2016.
 */
public class League {
    //Attributes found in Database


    //Methods

    //getters and setters

    //views (such as display)
}
